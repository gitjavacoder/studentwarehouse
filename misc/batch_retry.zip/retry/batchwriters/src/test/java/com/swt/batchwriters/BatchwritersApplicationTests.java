package com.swt.batchwriters;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BatchwritersApplicationTests {

    @Test
    void contextLoads() {
    }

}
