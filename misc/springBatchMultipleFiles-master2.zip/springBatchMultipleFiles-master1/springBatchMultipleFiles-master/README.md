# springBatchMultipleFiles
Processing multiple files with Spring batch.
This is the working implementation of the article https://howtodoinjava.com/spring-batch/multiresourceitemreader-read-multiple-csv-files-example/ 
Provided here just as a convenience and with no intention of copyright infringement
